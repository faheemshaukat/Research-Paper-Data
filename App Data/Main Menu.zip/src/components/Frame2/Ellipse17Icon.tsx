import { memo, SVGProps } from 'react';

const Ellipse17Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 199 250' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={99.5} cy={125} rx={99.5} ry={125} fill='black' stroke='black' strokeWidth={10} />
  </svg>
);

const Memo = memo(Ellipse17Icon);
export { Memo as Ellipse17Icon };
