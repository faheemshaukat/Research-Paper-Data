import { memo, SVGProps } from 'react';

const CodeIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M16.7666 18.0645L22.7666 12.0645L16.7666 6.06445'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M8.7666 6.06445L2.7666 12.0645L8.7666 18.0645'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(CodeIcon2);
export { Memo as CodeIcon2 };
