import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { BxsFileIcon } from './BxsFileIcon.js';
import { ChevronDownIcon } from './ChevronDownIcon.js';
import { CodeIcon2 } from './CodeIcon2.js';
import { CodeIcon } from './CodeIcon.js';
import { Ellipse13Icon } from './Ellipse13Icon.js';
import { Ellipse14Icon } from './Ellipse14Icon.js';
import { Ellipse15Icon } from './Ellipse15Icon.js';
import { Ellipse16Icon } from './Ellipse16Icon.js';
import { Ellipse17Icon } from './Ellipse17Icon.js';
import { Ellipse18Icon } from './Ellipse18Icon.js';
import classes from './Frame2.module.css';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon4 } from './VectorIcon4.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 481:534 */
export const Frame2: FC<Props> = memo(function Frame2(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle31}></div>
      <div className={classes.rectangle15}></div>
      <div className={classes.genVisVisualizingMovieTrailerG}>
        GenVis: Visualizing Movie Trailer Genre Classification
      </div>
      <div className={classes.rectangle18}></div>
      <div className={classes.code}>
        <CodeIcon className={classes.icon} />
      </div>
      <div className={classes.code2}>
        <CodeIcon2 className={classes.icon2} />
      </div>
      <div className={classes.chevronDown}>
        <ChevronDownIcon className={classes.icon3} />
      </div>
      <div className={classes.mainMenuForVideoVisualAnalysis}>Main Menu For Video Visual Analysis</div>
      <div className={classes.rectangle30}></div>
      <div className={classes.vector}>
        <VectorIcon className={classes.icon4} />
      </div>
      <div className={classes.vector2}>
        <VectorIcon2 className={classes.icon5} />
      </div>
      <div className={classes.vector3}>
        <VectorIcon3 className={classes.icon6} />
      </div>
      <div className={classes.adventure}>Adventure</div>
      <div className={classes.romance}>Romance</div>
      <div className={classes.horror}>Horror</div>
      <div className={classes.action}>Action</div>
      <div className={classes.fantasy}>Fantasy</div>
      <div className={classes.family}>Family</div>
      <div className={classes.ellipse13}>
        <Ellipse13Icon className={classes.icon7} />
      </div>
      <div className={classes.ellipse14}>
        <Ellipse14Icon className={classes.icon8} />
      </div>
      <div className={classes.ellipse15}>
        <Ellipse15Icon className={classes.icon9} />
      </div>
      <div className={classes.ellipse16}>
        <Ellipse16Icon className={classes.icon10} />
      </div>
      <div className={classes.ellipse17}>
        <Ellipse17Icon className={classes.icon11} />
      </div>
      <div className={classes.ellipse18}>
        <Ellipse18Icon className={classes.icon12} />
      </div>
      <div className={classes.allViews}>All Views</div>
      <div className={classes.genreTimelineView}>Genre Timeline View</div>
      <div className={classes.vector4}>
        <VectorIcon4 className={classes.icon13} />
      </div>
      <div className={classes.overallGenreView}>Overall Genre View</div>
      <div className={classes.genreFlowSummery}>Genre Flow Summery</div>
      <div className={classes.rectangle32}></div>
      <div className={classes.bxsFile}>
        <BxsFileIcon className={classes.icon14} />
      </div>
      <div className={classes.browseVideoPath}>Browse Video Path </div>
      <div className={classes.rectangle33}></div>
      <div className={classes.start}>Start</div>
      <div className={classes._2}></div>
    </div>
  );
});
