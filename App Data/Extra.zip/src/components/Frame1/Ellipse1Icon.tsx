import { memo, SVGProps } from 'react';

const Ellipse1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 167 114' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={83.6757} cy={57} rx={83.1787} ry={57} fill='#4AA3F5' />
  </svg>
);

const Memo = memo(Ellipse1Icon);
export { Memo as Ellipse1Icon };
