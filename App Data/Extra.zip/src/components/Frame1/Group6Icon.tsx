import { memo, SVGProps } from 'react';

const Group6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 114 188' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0.44384 118.685L56.9558 187.547L113.468 118.685' fill='black' />
    <path
      d='M0.44384 118.685L56.9558 187.547L113.468 118.685'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path d='M113.468 68.9654L56.9558 0.103455L0.44384 68.9654' fill='black' />
    <path
      d='M113.468 68.9654L56.9558 0.103455L0.44384 68.9654'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Group6Icon);
export { Memo as Group6Icon };
