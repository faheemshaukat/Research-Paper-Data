import { memo, SVGProps } from 'react';

const Ellipse3Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 592 487' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={296} cy={243.5} rx={296} ry={243.5} fill='white' stroke='black' strokeWidth={40} />
  </svg>
);

const Memo = memo(Ellipse3Icon);
export { Memo as Ellipse3Icon };
