import { memo, SVGProps } from 'react';

const Group7Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 114 188' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0.656242 118.685L57.1682 187.547L113.68 118.685' fill='black' />
    <path
      d='M0.656242 118.685L57.1682 187.547L113.68 118.685'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path d='M113.68 68.9654L57.1682 0.103455L0.656242 68.9654' fill='black' />
    <path
      d='M113.68 68.9654L57.1682 0.103455L0.656242 68.9654'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Group7Icon);
export { Memo as Group7Icon };
