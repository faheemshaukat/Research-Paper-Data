import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Component1_Property1Group7 } from './Component1_Property1Group7/Component1_Property1Group7.js';
import { Ellipse1Icon } from './Ellipse1Icon.js';
import { Ellipse3Icon } from './Ellipse3Icon.js';
import classes from './Frame1.module.css';
import { Group6Icon } from './Group6Icon.js';
import { Group7Icon } from './Group7Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 412:92 */
export const Frame1: FC<Props> = memo(function Frame1(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame2}>
        <div className={classes.movieGenreGenreOrientedSummari}>
          Movie Genre: Genre-Oriented Summarization of movies
        </div>
        <div className={classes.ellipse3}>
          <Ellipse3Icon className={classes.icon2} />
        </div>
        <div className={classes.b}>b</div>
        <div className={classes.rectangle18}></div>
        <div className={classes.rectangle20}></div>
        <div className={classes.rectangle11}></div>
        <div className={classes.selectedMovieTrailer}>Selected Movie Trailer</div>
        <div className={classes._5}>5</div>
        <div className={classes.interval101205s}>Interval: [10-120]: 5s</div>
        <div className={classes.genreTimelineOccurrence}>Genre Timeline Occurrence</div>
        <div className={classes.rectangle13}></div>
        <div className={classes.graph}>Graph</div>
        <div className={classes.barChart}>Bar Chart</div>
        <div className={classes.rectangle17}></div>
        <div className={classes.sortBy}>Sort by</div>
        <div className={classes.action}>Action</div>
        <div className={classes.selectedMovieView}>Selected Movie View</div>
        <Component1_Property1Group7
          className={classes.component1}
          classes={{ dwn: classes.dwn, top: classes.top }}
          swap={{
            ellipse1: <Ellipse1Icon className={classes.icon} />,
          }}
        />
        <div className={classes._5MoviesStacked1}></div>
        <div className={classes._5MoviesStacked2}></div>
      </div>
      <div className={classes.rectangle132}></div>
      <div className={classes.graph2}>Graph</div>
      <div className={classes.barChart2}>Bar Chart</div>
      <div className={classes.group6}>
        <Group6Icon className={classes.icon3} />
      </div>
      <div className={classes.group7}>
        <Group7Icon className={classes.icon4} />
      </div>
    </div>
  );
});
