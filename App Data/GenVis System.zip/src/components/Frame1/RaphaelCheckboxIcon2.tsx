import { memo, SVGProps } from 'react';

const RaphaelCheckboxIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 413 422' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M335.562 362.656H77.4375C72.3031 362.656 67.3789 360.572 63.7484 356.862C60.1178 353.153 58.0781 348.121 58.0781 342.875V79.125C58.0781 68.1794 66.7253 59.3438 77.4375 59.3438H335.562C346.249 59.3438 354.922 68.1794 354.922 79.125V342.875C354.922 348.121 352.882 353.153 349.252 356.862C345.621 360.572 340.697 362.656 335.562 362.656ZM96.7969 323.094H316.203V98.9062H96.7969V323.094Z'
      fill='black'
    />
  </svg>
);

const Memo = memo(RaphaelCheckboxIcon2);
export { Memo as RaphaelCheckboxIcon2 };
