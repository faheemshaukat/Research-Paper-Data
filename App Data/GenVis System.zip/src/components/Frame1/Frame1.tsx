import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { ChevronDownIcon } from './ChevronDownIcon.js';
import { CodeIcon2 } from './CodeIcon2.js';
import { CodeIcon } from './CodeIcon.js';
import { Component1_Property1Group7 } from './Component1_Property1Group7/Component1_Property1Group7.js';
import { Ellipse1Icon } from './Ellipse1Icon.js';
import { Ellipse6Icon } from './Ellipse6Icon.js';
import { Ellipse7Icon } from './Ellipse7Icon.js';
import { Ellipse13Icon } from './Ellipse13Icon.js';
import { Ellipse14Icon } from './Ellipse14Icon.js';
import { Ellipse15Icon } from './Ellipse15Icon.js';
import { Ellipse16Icon } from './Ellipse16Icon.js';
import { Ellipse17Icon } from './Ellipse17Icon.js';
import { Ellipse18Icon } from './Ellipse18Icon.js';
import classes from './Frame1.module.css';
import { Group6Icon } from './Group6Icon.js';
import { Group7Icon } from './Group7Icon.js';
import { Group8Icon } from './Group8Icon.js';
import { GroupIcon2 } from './GroupIcon2.js';
import { GroupIcon3 } from './GroupIcon3.js';
import { GroupIcon } from './GroupIcon.js';
import { NotoRadioButtonIcon2 } from './NotoRadioButtonIcon2.js';
import { NotoRadioButtonIcon3 } from './NotoRadioButtonIcon3.js';
import { NotoRadioButtonIcon } from './NotoRadioButtonIcon.js';
import { RaphaelCheckboxIcon2 } from './RaphaelCheckboxIcon2.js';
import { RaphaelCheckboxIcon3 } from './RaphaelCheckboxIcon3.js';
import { RaphaelCheckboxIcon } from './RaphaelCheckboxIcon.js';
import { Rectangle28Icon } from './Rectangle28Icon.js';
import { Rectangle29Icon } from './Rectangle29Icon.js';
import { TrashIcon } from './TrashIcon.js';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon4 } from './VectorIcon4.js';
import { VectorIcon5 } from './VectorIcon5.js';
import { VectorIcon6 } from './VectorIcon6.js';
import { VectorIcon7 } from './VectorIcon7.js';
import { VectorIcon8 } from './VectorIcon8.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 501:9 */
export const Frame1: FC<Props> = memo(function Frame1(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle31}></div>
      <div className={classes.trash}>
        <TrashIcon className={classes.icon2} />
      </div>
      <div className={classes.rectangle15}></div>
      <div className={classes.genVisVisualizingMovieTrailerG}>
        GenVis: Visualizing Movie Trailer Genre Classification
      </div>
      <div className={classes.rectangle14}></div>
      <div className={classes.rectangle16}></div>
      <div className={classes.sortBy}>Sort By</div>
      <div className={classes.rectangle28}>
        <Rectangle28Icon className={classes.icon3} />
      </div>
      <div className={classes.rectangle13}></div>
      <div className={classes.graph}>Graph</div>
      <div className={classes.barChart}>Bar Chart</div>
      <div className={classes.group6}>
        <Group6Icon className={classes.icon4} />
      </div>
      <div className={classes.rectangle17}></div>
      <div className={classes.genre}>Genre</div>
      <div className={classes.action}>Action</div>
      <div className={classes.group7}>
        <Group7Icon className={classes.icon5} />
      </div>
      <div className={classes.genreFlowSummery}>Genre Flow Summery</div>
      <div className={classes.c}>c</div>
      <div className={classes.d}>d</div>
      <div className={classes.genreTimelineView}>Genre Timeline View</div>
      <div className={classes.interval1012010s}>Interval: [10-120]: 10s</div>
      <Component1_Property1Group7
        className={classes.component1}
        classes={{ dwn: classes.dwn, top: classes.top }}
        swap={{
          ellipse1: <Ellipse1Icon className={classes.icon} />,
        }}
      />
      <div className={classes.movieGenreGenreOrientedSummari}>Movie Genre: Genre-Oriented Summarization of movies</div>
      <div className={classes.rectangle2}></div>
      <div className={classes.overallGenreView}>Overall Genre View</div>
      <div className={classes.b}>b</div>
      <div className={classes.rectangle29}>
        <Rectangle29Icon className={classes.icon6} />
      </div>
      <div className={classes.rectangle312}></div>
      <div className={classes.ellipse7}>
        <Ellipse7Icon className={classes.icon7} />
      </div>
      <div className={classes.topGenresSlider}>Top Genres Slider</div>
      <div className={classes.ellipse6}>
        <Ellipse6Icon className={classes.icon8} />
      </div>
      <div className={classes._4}>4</div>
      <div className={classes._5}>5</div>
      <div className={classes._6}>6</div>
      <div className={classes._3}>3</div>
      <div className={classes._2}>2</div>
      <div className={classes.line1}></div>
      <div className={classes._1}>1</div>
      <div className={classes.line2}></div>
      <div className={classes.line6}></div>
      <div className={classes.line7}></div>
      <div className={classes.line8}></div>
      <div className={classes.line9}></div>
      <div className={classes.line10}></div>
      <div className={classes.rectangle18}></div>
      <div className={classes.a}>a</div>
      <div className={classes.rectangle11}></div>
      <div className={classes.code}>
        <CodeIcon className={classes.icon9} />
      </div>
      <div className={classes.code2}>
        <CodeIcon2 className={classes.icon10} />
      </div>
      <div className={classes.chevronDown}>
        <ChevronDownIcon className={classes.icon11} />
      </div>
      <div className={classes.movie5LinesAndRomBarCombine1}></div>
      <div className={classes.rectangle37}></div>
      <div className={classes.action2}>Action</div>
      <div className={classes.group8}>
        <Group8Icon className={classes.icon12} />
      </div>
      <div className={classes.movieTrailer}>Movie Trailer</div>
      <div className={classes.theTwilightSaga}> The Twilight Saga</div>
      <div className={classes.videoView}>Video View</div>
      <div className={classes.rectangle30}></div>
      <div className={classes.genreTimelineView2}>Genre Timeline View</div>
      <div className={classes.overallGenreView2}>Overall Genre View</div>
      <div className={classes.allViews}>All Views</div>
      <div className={classes.genreFlowSummery2}>Genre Flow Summery</div>
      <div className={classes.vector}>
        <VectorIcon className={classes.icon13} />
      </div>
      <div className={classes.raphaelCheckbox}>
        <RaphaelCheckboxIcon className={classes.icon14} />
      </div>
      <div className={classes.vector2}>
        <VectorIcon2 className={classes.icon15} />
      </div>
      <div className={classes.raphaelCheckbox2}>
        <RaphaelCheckboxIcon2 className={classes.icon16} />
      </div>
      <div className={classes.raphaelCheckbox3}>
        <RaphaelCheckboxIcon3 className={classes.icon17} />
      </div>
      <div className={classes.rectangle302}></div>
      <div className={classes.adventure}>Adventure</div>
      <div className={classes.adventure2}>Adventure</div>
      <div className={classes.romance}>Romance</div>
      <div className={classes.simple}>Simple</div>
      <div className={classes.romance2}>Romance</div>
      <div className={classes.horror}>Horror</div>
      <div className={classes.horror2}>Horror</div>
      <div className={classes.selectChart}>Select Chart </div>
      <div className={classes.pie}>Pie</div>
      <div className={classes.lollipop}>Lollipop</div>
      <div className={classes.polar}>Polar</div>
      <div className={classes.action3}>Action</div>
      <div className={classes.action4}>Action</div>
      <div className={classes.fantasy}>Fantasy</div>
      <div className={classes.fantasy2}>Fantasy</div>
      <div className={classes.family}>Family</div>
      <div className={classes.family2}>Family</div>
      <div className={classes.vector3}>
        <VectorIcon3 className={classes.icon18} />
      </div>
      <div className={classes.vector4}>
        <VectorIcon4 className={classes.icon19} />
      </div>
      <div className={classes.vector5}>
        <VectorIcon5 className={classes.icon20} />
      </div>
      <div className={classes.vector6}>
        <VectorIcon6 className={classes.icon21} />
      </div>
      <div className={classes.vector7}>
        <VectorIcon7 className={classes.icon22} />
      </div>
      <div className={classes.vector8}>
        <VectorIcon8 className={classes.icon23} />
      </div>
      <div className={classes.ellipse13}>
        <Ellipse13Icon className={classes.icon24} />
      </div>
      <div className={classes.ellipse14}>
        <Ellipse14Icon className={classes.icon25} />
      </div>
      <div className={classes.ellipse15}>
        <Ellipse15Icon className={classes.icon26} />
      </div>
      <div className={classes.ellipse16}>
        <Ellipse16Icon className={classes.icon27} />
      </div>
      <div className={classes.ellipse17}>
        <Ellipse17Icon className={classes.icon28} />
      </div>
      <div className={classes.ellipse18}>
        <Ellipse18Icon className={classes.icon29} />
      </div>
      <div className={classes.notoRadioButton}>
        <NotoRadioButtonIcon className={classes.icon30} />
      </div>
      <div className={classes.notoRadioButton2}>
        <NotoRadioButtonIcon2 className={classes.icon31} />
      </div>
      <div className={classes.notoRadioButton3}>
        <NotoRadioButtonIcon3 className={classes.icon32} />
      </div>
      <div className={classes.rectangle32}></div>
      <div className={classes.rectangle34}></div>
      <div className={classes.pieAll61}></div>
      <div className={classes.group}>
        <GroupIcon className={classes.icon33} />
      </div>
      <div className={classes.group2}>
        <GroupIcon2 className={classes.icon34} />
      </div>
      <div className={classes.group3}>
        <GroupIcon3 className={classes.icon35} />
      </div>
      <div className={classes.rectangle33}></div>
      <div className={classes.mainMenu}>Main Menu</div>
      <div className={classes.stackedAll61}></div>
      <div className={classes.rectangle35}></div>
      <div className={classes.mainMenu2}>Main Menu</div>
      <div className={classes.actionTimelineView1}></div>
      <div className={classes.rectangle36}></div>
      <div className={classes.mainMenu3}>Main Menu</div>
    </div>
  );
});
