import { memo, SVGProps } from 'react';

const Ellipse17Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 331 344' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={165.5} cy={172} rx={165.5} ry={172} fill='black' stroke='black' strokeWidth={10} />
  </svg>
);

const Memo = memo(Ellipse17Icon);
export { Memo as Ellipse17Icon };
