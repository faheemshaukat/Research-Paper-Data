import { memo, SVGProps } from 'react';

const VectorIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 300 300' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M280.435 300H19.5652C14.3762 300 9.39971 297.939 5.73052 294.269C2.06133 290.6 0 285.624 0 280.435V19.5652C0 8.73913 8.73913 0 19.5652 0H280.435C291.235 0 300 8.73913 300 19.5652V280.435C300 285.624 297.939 290.6 294.269 294.269C290.6 297.939 285.624 300 280.435 300ZM39.1304 260.87H260.87V39.1304H39.1304V260.87Z'
      fill='black'
    />
  </svg>
);

const Memo = memo(VectorIcon2);
export { Memo as VectorIcon2 };
