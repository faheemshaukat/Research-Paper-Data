import { memo, SVGProps } from 'react';

const Ellipse6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 223 255' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={111.5} cy={127.5} rx={111.5} ry={127.5} fill='black' />
  </svg>
);

const Memo = memo(Ellipse6Icon);
export { Memo as Ellipse6Icon };
