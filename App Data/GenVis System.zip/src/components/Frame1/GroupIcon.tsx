import { memo, SVGProps } from 'react';

const GroupIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 350 350' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M221.371 0.076416V68.1031C221.371 77.3159 225.486 86.1692 232.826 92.6957C240.184 99.2291 250.145 102.896 260.529 102.892H348.029'
      stroke='black'
      strokeWidth={24.5625}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M350 110.079V272.163C349.578 282.764 346.808 293.187 341.849 302.829C336.891 312.472 329.842 321.145 321.109 328.347C303.452 342.955 280.013 350.712 255.945 349.913H94.9455C82.9544 350.408 70.9718 348.784 59.6868 345.135C48.4018 341.486 38.0368 335.884 29.1879 328.65C20.374 321.425 13.2556 312.712 8.24531 303.016C3.23502 293.319 0.432435 282.832 0 272.163V77.8063C0.421152 67.2045 3.19078 56.7819 8.14926 47.1391C13.1077 37.4963 20.157 28.8239 28.8909 21.6218C46.5482 7.01448 69.9867 -0.742444 94.0545 0.0560711H215.261C233.762 0.00325368 251.621 6.10801 265.342 17.1763L328.13 68.6692C334.829 73.817 340.238 80.1644 344.006 87.2988C347.774 94.4331 349.816 102.195 350 110.079Z'
      stroke='black'
      strokeWidth={24.5625}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M228.242 165.792L121.545 260.984M121.523 166L228.263 261.192'
      stroke='black'
      strokeWidth={24.5625}
      strokeMiterlimit={10}
      strokeLinecap='round'
    />
  </svg>
);

const Memo = memo(GroupIcon);
export { Memo as GroupIcon };
