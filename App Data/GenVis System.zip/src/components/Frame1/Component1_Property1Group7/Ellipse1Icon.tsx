import { memo, SVGProps } from 'react';

const Ellipse1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 124 114' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={62} cy={57} rx={62} ry={57} fill='white' />
  </svg>
);

const Memo = memo(Ellipse1Icon);
export { Memo as Ellipse1Icon };
