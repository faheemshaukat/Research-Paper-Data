import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './Component1_Property1Group7.module.css';
import { Ellipse1Icon } from './Ellipse1Icon.js';

interface Props {
  className?: string;
  classes?: {
    dwn?: string;
    top?: string;
    root?: string;
  };
  swap?: {
    ellipse1?: ReactNode;
  };
}
/* @figmaId 28:125 */
export const Component1_Property1Group7: FC<Props> = memo(function Component1_Property1Group7(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={`${props.classes?.dwn || ''} ${classes.dwn}`}></div>
      <div className={`${props.classes?.top || ''} ${classes.top}`}></div>
      <div className={classes.ellipse1}>{props.swap?.ellipse1 || <Ellipse1Icon className={classes.icon} />}</div>
    </div>
  );
});
