import { memo, SVGProps } from 'react';

const Ellipse14Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 332 344' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={166} cy={172} rx={166} ry={172} fill='#008000' />
  </svg>
);

const Memo = memo(Ellipse14Icon);
export { Memo as Ellipse14Icon };
