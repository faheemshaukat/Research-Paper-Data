import { memo, SVGProps } from 'react';

const RaphaelCheckboxIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 413 423' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect y={0.933594} width={413} height={422} stroke='black' />
    <path
      d='M335.562 363.59H77.4375C72.3031 363.59 67.3789 361.506 63.7484 357.796C60.1178 354.086 58.0781 349.055 58.0781 343.809V80.0586C58.0781 69.113 66.7253 60.2773 77.4375 60.2773H335.562C346.249 60.2773 354.922 69.113 354.922 80.0586V343.809C354.922 349.055 352.882 354.086 349.252 357.796C345.621 361.506 340.697 363.59 335.562 363.59ZM96.7969 324.027H316.203V99.8398H96.7969V324.027Z'
      fill='black'
    />
  </svg>
);

const Memo = memo(RaphaelCheckboxIcon3);
export { Memo as RaphaelCheckboxIcon3 };
