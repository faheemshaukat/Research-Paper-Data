import { memo, SVGProps } from 'react';

const Group7Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 106 188' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0.000656128 118.729L52.9359 187.676L105.871 118.729' fill='black' />
    <path
      d='M0.000656128 118.729L52.9359 187.676L105.871 118.729'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path d='M105.871 68.9471L52.9359 0L0.000656128 68.9471' fill='black' />
    <path
      d='M105.871 68.9471L52.9359 0L0.000656128 68.9471'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Group7Icon);
export { Memo as Group7Icon };
