import { memo, SVGProps } from 'react';

const TrashIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect width={24} height={24} transform='translate(0.914062 0.0908203)' fill='black' />
    <path
      d='M3.91406 6.09082H5.91406H21.9141'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M19.9141 6.09082V20.0908C19.9141 20.6213 19.7033 21.13 19.3283 21.505C18.9532 21.8801 18.4445 22.0908 17.9141 22.0908H7.91406C7.38363 22.0908 6.87492 21.8801 6.49985 21.505C6.12478 21.13 5.91406 20.6213 5.91406 20.0908V6.09082M8.91406 6.09082V4.09082C8.91406 3.56039 9.12478 3.05168 9.49985 2.67661C9.87492 2.30153 10.3836 2.09082 10.9141 2.09082H14.9141C15.4445 2.09082 15.9532 2.30153 16.3283 2.67661C16.7033 3.05168 16.9141 3.56039 16.9141 4.09082V6.09082'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(TrashIcon);
export { Memo as TrashIcon };
