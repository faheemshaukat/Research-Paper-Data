import { memo, SVGProps } from 'react';

const Rectangle29Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 11645 7487' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M11645 0H0V7487H11645V0Z' stroke='black' strokeWidth={20} />
  </svg>
);

const Memo = memo(Rectangle29Icon);
export { Memo as Rectangle29Icon };
