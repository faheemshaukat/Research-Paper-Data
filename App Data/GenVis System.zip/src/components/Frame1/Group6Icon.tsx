import { memo, SVGProps } from 'react';

const Group6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 107 188' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0.748703 118.729L53.6839 187.676L106.619 118.729' fill='black' />
    <path
      d='M0.748703 118.729L53.6839 187.676L106.619 118.729'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path d='M106.619 68.9471L53.6839 0L0.748703 68.9471' fill='black' />
    <path
      d='M106.619 68.9471L53.6839 0L0.748703 68.9471'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Group6Icon);
export { Memo as Group6Icon };
