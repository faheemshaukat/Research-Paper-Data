import { memo, SVGProps } from 'react';

const Rectangle28Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 11650 475' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H11650V475H0V0Z' fill='white' stroke='black' strokeWidth={20} />
  </svg>
);

const Memo = memo(Rectangle28Icon);
export { Memo as Rectangle28Icon };
