import { memo, SVGProps } from 'react';

const Ellipse11Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 210 255' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={105} cy={127.5} rx={105} ry={127.5} fill='black' />
  </svg>
);

const Memo = memo(Ellipse11Icon);
export { Memo as Ellipse11Icon };
