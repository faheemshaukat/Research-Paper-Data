import { memo, SVGProps } from 'react';

const Group7Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 118 249' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0.462307 157.487L59.1926 248.941L117.923 157.487' fill='black' />
    <path
      d='M0.462307 157.487L59.1926 248.941L117.923 157.487'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path d='M117.923 91.4546L59.1926 0L0.462307 91.4546' fill='black' />
    <path
      d='M117.923 91.4546L59.1926 0L0.462307 91.4546'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Group7Icon);
export { Memo as Group7Icon };
