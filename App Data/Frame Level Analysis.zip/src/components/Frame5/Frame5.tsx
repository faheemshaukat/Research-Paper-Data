import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Ellipse6Icon } from './Ellipse6Icon.js';
import { Ellipse11Icon } from './Ellipse11Icon.js';
import classes from './Frame5.module.css';
import { Group7Icon } from './Group7Icon.js';
import { NotoRadioButtonIcon2 } from './NotoRadioButtonIcon2.js';
import { NotoRadioButtonIcon } from './NotoRadioButtonIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 410:17 */
export const Frame5: FC<Props> = memo(function Frame5(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.movieGenreGenreOrientedSummari}>Movie Genre: Genre-Oriented Summarization of movies</div>
      <div className={classes.rectangle18}></div>
      <div className={classes.rectangle20}></div>
      <div className={classes.rectangle11}></div>
      <div className={classes.movieTrailer}>Movie Trailer</div>
      <div className={classes.hanselGretel}>Hansel &amp; Gretel</div>
      <div className={classes.a}>a</div>
      <div className={classes.frameGenreAnalysis}>Frame Genre Analysis</div>
      <div className={classes.rectangle13}></div>
      <div className={classes.importFrame}>Import Frame</div>
      <div className={classes.frame140}>Frame@1:40</div>
      <div className={classes.rectangle17}></div>
      <div className={classes.pauseAt}>Pause at</div>
      <div className={classes._140}>1:40</div>
      <div className={classes.group7}>
        <Group7Icon className={classes.icon} />
      </div>
      <div className={classes.frameAnalysisView}>Frame Analysis View</div>
      <div className={classes.frame3}></div>
      <div className={classes.ellipse6}>
        <Ellipse6Icon className={classes.icon2} />
      </div>
      <div className={classes.sTART}>START</div>
      <div className={classes.b}>b</div>
      <div className={classes.movie5LinesAndRomBarCombine1}></div>
      <div className={classes.donut}>Donut</div>
      <div className={classes.pie}>Pie</div>
      <div className={classes.notoRadioButton}>
        <NotoRadioButtonIcon className={classes.icon3} />
      </div>
      <div className={classes.notoRadioButton2}>
        <NotoRadioButtonIcon2 className={classes.icon4} />
      </div>
      <div className={classes.rectangle40}></div>
      <div className={classes.rectangle39}></div>
      <div className={classes.topGenresSlider}>Top Genres Slider</div>
      <div className={classes.ellipse11}>
        <Ellipse11Icon className={classes.icon5} />
      </div>
      <div className={classes._4}>4</div>
      <div className={classes._5}>5</div>
      <div className={classes._6}>6</div>
      <div className={classes._3}>3</div>
      <div className={classes._2}>2</div>
      <div className={classes.line18}></div>
      <div className={classes._1}>1</div>
      <div className={classes.line19}></div>
      <div className={classes.line20}></div>
      <div className={classes.line21}></div>
      <div className={classes.line22}></div>
      <div className={classes.line23}></div>
      <div className={classes.line24}></div>
      <div className={classes.frameDonut1}></div>
    </div>
  );
});
