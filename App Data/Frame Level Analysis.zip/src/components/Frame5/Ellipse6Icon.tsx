import { memo, SVGProps } from 'react';

const Ellipse6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1360 448' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={680} cy={224} rx={680} ry={224} fill='white' stroke='black' strokeWidth={10} />
  </svg>
);

const Memo = memo(Ellipse6Icon);
export { Memo as Ellipse6Icon };
